package BaiToanTinhCong;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int count=1;
        while (sc.hasNext()){
            System.out.println(new NhanVien(count++,sc.nextLine(),Long.parseLong(sc.nextLine())
                    ,Long.parseLong(sc.nextLine()),sc.nextLine()));
        }
    }
}
