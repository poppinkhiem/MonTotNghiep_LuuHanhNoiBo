package TinhLuong;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
  public static void main(String[] args) throws FileNotFoundException {
    Scanner sc=new Scanner(System.in);
//     sc=new Scanner(new File("C:\\Users\\Admin\\Desktop\\SPOJ\\src\\input.txt"));
    int t=Integer.parseInt(sc.nextLine());
    HashMap<String,String> map=new HashMap<>();
    for(int i=0;i<t;i++)
      map.put(sc.next(),sc.nextLine());
    t= Integer.parseInt(sc.nextLine());
    for(int i=0;i<t;i++){
      System.out.println(new NhanVien(sc.nextLine(), sc.nextLine(), Long.parseLong(sc.nextLine()),Long.parseLong(
          sc.nextLine()),map));
    }
  }
}
