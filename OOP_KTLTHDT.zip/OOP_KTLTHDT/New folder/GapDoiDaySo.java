import java.util.Scanner;

public class GapDoiDaySo {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int t=sc.nextInt();
        while (t-->0){
            int n=sc.nextInt();long k= sc.nextLong();
            System.out.println(tinh(n,k));
        }
    }

    private static long tinh(int n, long k) {
        long x=(long)Math.pow(2,n-1);
        if(k==x) return n;
        else if(k<x) return tinh(n-1,k);
        return tinh(n-1,k-x);
    }
}
