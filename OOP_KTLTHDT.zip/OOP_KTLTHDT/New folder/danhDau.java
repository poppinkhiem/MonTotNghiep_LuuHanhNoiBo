import java.util.Scanner;

public class danhDau {
    public static void main(String[] args) {
        System.out.println(new Scanner(System.in).next().chars().distinct().count());
    }
}
