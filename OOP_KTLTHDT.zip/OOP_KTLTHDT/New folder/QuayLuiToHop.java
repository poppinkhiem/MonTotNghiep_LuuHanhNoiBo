import java.util.Scanner;

public class QuayLuiToHop {
    static int c[]=new int[20],n,k;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();k= sc.nextInt();
        quaylui(1);
    }

    private static void quaylui(int i) {
        for(int j=c[i-1]+1;j<=n-k+i;j++){
            c[i]=j;
            if(i==k) xuly();
            else quaylui(i+1);
        }
    }

    private static void xuly() {
        for(int i=1;i<=k;i++){
            System.out.print(c[i]+" ");
        }
        System.out.println();
    }
}
