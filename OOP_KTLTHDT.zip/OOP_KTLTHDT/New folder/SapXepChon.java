import java.util.Scanner;

public class SapXepChon {
    public static void main(String[] args) throws Exception{
        Scanner sc=new Scanner(System.in);
//        int t
//                =Integer.valueOf(sc.nextLine())
//                ;
//        while(t-->0){
        int n=sc.nextInt();
        int[] a=new int[n];
        for(int i=0;i<n;i++)
            a[i]=sc.nextInt();
        for(int i=0;i<n-1;i++){
            int index=i,min=a[i];
            for(int j=i+1;j<n;j++){
                if(a[i]>a[j]&&a[j]<min){
                    index=j;
                    min=a[j];
                }
            }
            int tmp=a[i];
            a[i]=a[index];
            a[index]=tmp;
            printfArray(a,i+1);
//                if(!isSorted(a))printfArray(a,i+1);
//                else {
//                    printfArray(a,i+1);
//                    break;
//                }
        }
//        }
    }

    private static boolean isSorted(int[] a) {
        for(int i=0;i<a.length-1;i++)
            if(a[i]>a[i+1]) return false;
        return true;
    }

    private static void printfArray(int[] a,int buoc) {
        System.out.format("Buoc %d: ",buoc);
        for(int i=0;i<a.length;i++)
            System.out.format("%d ",a[i]);
        System.out.println();
    }
}
