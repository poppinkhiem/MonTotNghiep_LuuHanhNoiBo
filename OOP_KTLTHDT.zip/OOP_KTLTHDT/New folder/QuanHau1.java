import java.util.Scanner;

public class QuanHau1 {
    static int a[],b[],nguoc[],xuoi[],n,kq;
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int t=sc.nextInt();
        while (t-->0){
            n=sc.nextInt();
            a=new int[15];
            b=new int[15];
            nguoc=new int[30];
            xuoi=new int[30];
            kq=0;
            quaylui(1);
            System.out.println(kq);
        }
    }

    private static void quaylui(int i) {
        for(int j=1;j<=n;j++){
            if(b[j]==0&&xuoi[i-j+n]==0&&nguoc[i+j-1]==0){
                a[i]=j;
                b[j]=1;xuoi[i-j+n]=1;nguoc[i+j-1]=1;
                if(i==n) kq++;
                else quaylui(i+1);
                b[j]=0;xuoi[i-j+n]=0;nguoc[i+j-1]=0;
            }
        }
    }
}
