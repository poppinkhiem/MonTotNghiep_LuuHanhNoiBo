import java.util.Arrays;
import java.util.Scanner;

public class DayConCoTongLe {
    static int a[],b[],n;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int t= sc.nextInt();
        while(t-->0){
            a=new int[20];b=new int[20];
            n= sc.nextInt();
            int[] x=new int[n];
            for(int i=0;i<n;i++) x[i]=sc.nextInt();
            Arrays.sort(x);
            for(int i=1;i<=n;i++) a[i]=x[n-i];
            quaylui(1);
        }
    }

    private static void quaylui(int i) {
        for(int j=0;j<=1;j++){
            b[i]=j;
            if(i==n) xuly();
            else quaylui(i+1);
        }
    }

    private static void xuly() {
        int tong=0,i;
        for(i=1;i<=n;i++) tong+=a[i]*b[i];
        if(tong%2==1){
            for(i=1;i<=n;i++){
                if(b[i]==1) System.out.print(a[i]+" ");
            }
            System.out.println();
        }
    }
}
