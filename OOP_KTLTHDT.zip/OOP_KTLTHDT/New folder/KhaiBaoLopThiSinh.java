import java.util.Scanner;

public class KhaiBaoLopThiSinh {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String name=sc.nextLine();
        String dateOfBirth=sc.nextLine();
        Float diem1=Float.valueOf(sc.nextLine());
        Float diem2=Float.valueOf(sc.nextLine());
        Float diem3=Float.valueOf(sc.nextLine());
        System.out.format("%s %s %.1f",name,dateOfBirth,diem1+diem2+diem3);
    }
}
