import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class DayConTangDanVetCan {
    static int a[],c[],n;
    static List<String> list=new ArrayList<>();
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();
        a=new int[n];
        c=new int[n+1];
        for(int i=0;i<n;i++) a[i]=sc.nextInt();
        quaylui(1);
        Collections.sort(list);
        for(String s:list)
            System.out.println(s);
    }

    private static void quaylui(int i) {
        for(int j=0;j<=1;j++){
            c[i]=j;
            if(i==n) xuly();
            else quaylui(i+1);
        }
    }

    private static void xuly() {
        String tmp="";
        int hehe[]=new int[n],count=0;
        for(int i=1;i<=n;i++){
            if(c[i]==1){
                tmp+=a[i-1]+" ";
                hehe[count++]=a[i-1];
            }
        }
        for(int i=1;i<count;i++){
            if(hehe[i]<hehe[i-1]) return;
        }
        if(count>1&&tmp!="")
        list.add(tmp);
    }
}
