import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class ChuanHoaCauTest {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc=new Scanner(new File("C:/Users/Admin/Desktop/SPOJ/src/doanVan.txt"));
//        Scanner sc=new Scanner(System.in);
        ArrayList<String> list=new ArrayList<>();
        while(sc.hasNext()){
            list.add(sc.nextLine().trim().toLowerCase());
        }
        for(int i=0;i< list.size();i++){
            if(!list.get(i).equals("")){
                String trim = list.get(i);
                String[] split = trim.split("\\s+");
                char[] chars = split[0].toCharArray();
                if(chars[0]>='a'&&chars[0]<='z'){
                    chars[0]-=32;
                    System.out.print(new String(chars));
                }
                for(int j=1;j< split.length;j++){
                    if(split[j].equals("?")||split[j].equals("!")||split[j].equals("."))
                        System.out.print(split[j]);
                    else
                        System.out.print(" "+split[j]);
                };
                if(trim.charAt(trim.length()-1)!='?'&&trim.charAt(trim.length()-1)!='!'&&trim.charAt(trim.length()-1)!='.')
                    System.out.println(".");
                else System.out.println();
            }
        }
    }
}
